<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class VirtuemartMedias extends Model {
    
    protected $table = 'bxtnj_virtuemart_medias';
    
    protected $primaryKey = 'virtuemart_media_id';

    //protected $fillable = [];

}
