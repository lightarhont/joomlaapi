<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductCustomField extends Model {
    
    protected $table = 'bxtnj_virtuemart_product_customfields';
    
    protected $primaryKey = 'virtuemart_customfield_id';

}
