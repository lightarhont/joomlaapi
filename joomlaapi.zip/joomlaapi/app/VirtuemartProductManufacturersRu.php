<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class VirtuemartProductManufacturersRu extends Model {
    
    protected $table = 'bxtnj_virtuemart_manufacturers_ru_ru';
    
    protected $primaryKey = 'virtuemart_manufacturer_id';
    
}